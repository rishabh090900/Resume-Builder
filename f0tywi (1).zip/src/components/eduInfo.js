import React, { useRef, useState } from "react";
import { Button, TextField } from "@material-ui/core";
import MenuItem from "@material-ui/core/MenuItem";

import "../styles.css";
const options = [
  {
    label: "Month",
    value: "month"
  },
  {
    label: "January",
    value: "january"
  },
  {
    label: "February",
    value: "february"
  },
  {
    label: "March",
    value: "march"
  },
  {
    label: "April",
    value: "april"
  },
  {
    label: "May",
    value: "may"
  },
  {
    label: "June",
    value: "june"
  },
  {
    label: "July",
    value: "july"
  },
  {
    label: "August",
    value: "august"
  },
  {
    label: "September",
    value: "september"
  },
  {
    label: "October",
    value: "october"
  },
  {
    label: "November",
    value: "november"
  },
  {
    label: "December",
    value: "december"
  }
];
const years = [
  {
    label: "2022",
    value: "2022"
  },
  {
    label: "2021",
    value: "2021"
  },
  {
    label: "2020",
    value: "2020"
  },
  {
    label: "2019",
    value: "2019"
  },
  {
    label: "2018",
    value: "2018"
  },

  {
    label: "2017",
    value: "2017"
  },
  {
    label: "2016",
    value: "2016"
  },
  {
    label: "2015",
    value: "2015"
  }
];

const EduInfo = ({ handleNext, handleChange, formValues, handleBack, setFormValues }) => {
  const [eduIndex, setEduIndex] = useState(0);
  const [inputList, setinputList] = useState(true);

  const eduList = () => {
    return (
      <div>
        <h1 className="form-heading">Education Summary</h1>
        <Button onClick={handleaddclick}>Add More</Button>
        {formValues.Education.map((index, i) => (
          <div className="education-list" key={i}>
            <div className="education-list-degree">
              {index.Schoolname.value},{index.degree.value} | {index.monthStart.value}{" "}
              {index.yearStart.value} -{index.monthEnd.value} {index.yearEnd.value}
            </div>
            <div className="education-list-degree2">{index.Description.value}</div>
            {eduIndex > 0 ? (
              <Button className="btn-remove" onClick={() => handleRemove(i)}>
                Remove
              </Button>
            ) : null}
          </div>
        ))}
        <div className="stepButton">
          <Button onClick={handleBack}>Back</Button>
          <Button variant="contained" color="primary" onClick={handleNext}>
            Continue
          </Button>
        </div>
      </div>
    );
  };
  const handleRemove = (e) => {
    console.log(e);
    if (eduIndex > 0) {
      const elementRemove = formValues.Education[e];
      let removeEducation = formValues.Education.filter((Education) => Education !== elementRemove);
      setFormValues({ ...formValues, Education: removeEducation });

      setEduIndex((prevState) => prevState - 1);
    }
  };

  const input = (index) => {
    return (
      <form Validate onSubmit={handleShift}>
        <h1 className="form-heading">Education</h1>
        <p className="form-subheading">
          Add your most relevant education, including programs you’re currently enrolled in.
        </p>
        <TextField
          placeholder="Enter your School Name"
          label="School Name"
          name="Schoolname"
          variant="standard"
          fullWidth
          required
          className="field2-left"
          value={formValues.Education[index].Schoolname.value}
          onChange={(e) => handleChange1(e, index)}
          error={formValues.Education[index].Schoolname.error}
          helperText={
            formValues.Education[index].Schoolname.error &&
            formValues.Education[index].Schoolname.errorMessage
          }
        />
        <TextField
          placeholder="Enter your School Location"
          label="School Location"
          name="SchoolLocation"
          variant="standard"
          fullWidth
          className="field2-right"
          value={formValues.Education[index].SchoolLocation.value}
          onChange={(e) => handleChange1(e, index)}
        />
        <TextField
          id="standard-select-currency"
          className="Selectbox"
          select
          name="monthStart"
          onChange={(e) => handleChange1(e, index)}
          helperText="Please select Start Month"
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          className="Selectbox"
          name="yearStart"
          onChange={(e) => handleChange1(e, index)}
          helperText="Please select Start Year"
        >
          {years.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          name="monthEnd"
          className="Selectbox"
          onChange={(e) => handleChange1(e, index)}
          helperText="Please select end Month"
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          className="Selectbox"
          name="yearEnd"
          onChange={(e) => handleChange1(e, index)}
          helperText="Please select end Year"
        >
          {years.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          placeholder="Enter your Degree"
          label="Degree"
          name="degree"
          variant="standard"
          fullWidth
          required
          className="field1"
          value={formValues.Education[index].degree.value}
          onChange={(e) => handleChange1(e, index)}
          error={formValues.Education[index].degree.error}
          helperText={
            formValues.Education[index].degree.error &&
            formValues.Education[index].degree.errorMessage
          }
        />
        <TextField
          placeholder="Enter your Field of Study"
          label="Field of Study"
          name="fieldStudy"
          variant="standard"
          fullWidth
          className="field1"
          value={formValues.Education[index].fieldStudy.value}
          onChange={(e) => handleChange1(e, index)}
        />
        <TextField
          placeholder="Enter About your Studies"
          label="Description"
          name="fieldStudy"
          fullWidth
          multiline
          rows={3}
          className="field"
          value={formValues.Education[index].Description.value}
          onChange={(e) => handleChange1(e, index)}
        />
        <br></br>
        <div className="stepButton">
          <Button onClick={handleBack}>Back</Button>
          <Button type="submit" variant="contained" color="primary">
            Continue
          </Button>
        </div>
      </form>
    );
  };
  const handleShift = () => {
    setinputList((prevState) => !prevState);
  };
  const handleChange1 = (e, index) => {
    const { name, value } = e.target;
    const newEducation = formValues.Education.map((i, ind) => {
      if (index === ind) {
        i[name].value = value;
        // i[name] = value;
      }
      return i;
    });
    setFormValues({ ...formValues, Education: newEducation });
  };
  const handleaddclick = (index) => {
    const newList = formValues.Education;

    setFormValues({
      ...formValues,
      Education: [
        ...newList,
        {
          Schoolname: {
            value: "Cambridge University",
            error: false,
            errorMessage: "You must enter school name"
          },
          SchoolLocation: {
            value: "Jaipur"
          },
          degree: {
            value: "B.tech",
            error: false,
            errorMessage: "You must enter degree"
          },
          monthStart: {
            value: "july"
          },
          yearStart: {
            value: "2019"
          },

          monthEnd: {
            value: "july"
          },
          yearEnd: {
            value: "2023"
          },
          fieldStudy: {
            value: "Computer Science",
            error: false,
            errorMessage: "You must enter school name"
          },
          Description: {
            value: "Learned a lot in my betch , proficienct in Frontend and backend"
          }
        }
      ]
    });
    setEduIndex((prevState) => prevState + 1);
    setinputList((prevState) => !prevState);
  };
  return <div>{inputList ? input(eduIndex) : eduList()}</div>;
};
export default EduInfo;
