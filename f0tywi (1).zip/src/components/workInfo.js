import React, { useState } from "react";
import { Button, TextField } from "@material-ui/core";
import MenuItem from "@material-ui/core/MenuItem";

import "../styles.css";
const options = [
  {
    label: "Month",
    value: "month"
  },
  {
    label: "January",
    value: "january"
  },
  {
    label: "February",
    value: "february"
  },
  {
    label: "March",
    value: "march"
  },
  {
    label: "April",
    value: "april"
  },
  {
    label: "May",
    value: "may"
  },
  {
    label: "June",
    value: "june"
  },
  {
    label: "July",
    value: "july"
  },
  {
    label: "August",
    value: "august"
  },
  {
    label: "September",
    value: "september"
  },
  {
    label: "October",
    value: "october"
  },
  {
    label: "November",
    value: "november"
  },
  {
    label: "December",
    value: "december"
  }
];
const years = [
  {
    label: "2022",
    value: "2022"
  },
  {
    label: "2021",
    value: "2021"
  },
  {
    label: "2020",
    value: "2020"
  },
  {
    label: "2019",
    value: "2019"
  },
  {
    label: "2018",
    value: "2018"
  },

  {
    label: "2017",
    value: "2017"
  },
  {
    label: "2016",
    value: "2016"
  },
  {
    label: "2015",
    value: "2015"
  }
];

const WorkInfo = ({ handleSubmit, formValues, handleBack, setFormValues }) => {
  const [workIndex, setWorkIndex] = useState(0);
  const [workInputList, setworkInputList] = useState(true);

  const workList = () => {
    return (
      <div>
        <h1 className="form-heading">Experience Summary</h1>
        <Button onClick={handleaddclick}>Add More</Button>
        {formValues.workExp.map((index, i) => (
          <div className="education-list">
            <div className="education-list-degree">
              {index.Position.value},{index.CompanyName.value} | {index.monthStart.value}{" "}
              {index.yearStart.value} -{index.monthEnd.value} {index.yearEnd.value}
            </div>

            <div className="education-list-degree2">{index.Description.value}</div>
            {workIndex > 0 ? (
              <Button className="btn-remove" onClick={() => handleRemove(i)}>
                Remove
              </Button>
            ) : null}
          </div>
        ))}
        <div className="stepButton">
          <Button onClick={handleBack}>Back</Button>
          <Button variant="contained" color="primary" onClick={handleSubmit}>
            Continue
          </Button>
        </div>
      </div>
    );
  };
  const handleRemove = (e) => {
    console.log(e);
    if (workIndex > 0) {
      const elementRemove = formValues.workExp[e];
      let removeExp = formValues.workExp.filter((workExp) => workExp !== elementRemove);
      setFormValues({ ...formValues, workExp: removeExp });
      setWorkIndex((prevState) => prevState - 1);
    }
  };
  const handleChange = (e, index) => {
    const { name, value } = e.target;
    const newExperience = formValues.workExp.map((i, ind) => {
      if (index === ind) {
        i[name].value = value;
        // i[name] = value;
      }
      return i;
    });
    setFormValues({ ...formValues, workExp: newExperience });
  };
  const handleaddclick = (index) => {
    const newList = formValues.workExp;

    setFormValues({
      ...formValues,
      workExp: [
        ...newList,
        {
          Position: {
            value: "UI/Ux Intern"
          },
          CompanyName: {
            value: "Google"
          },

          monthStart: {
            value: "July"
          },

          yearStart: {
            value: "2021"
          },

          monthEnd: {
            value: "August"
          },
          yearEnd: {
            value: "2021"
          },
          Description: {
            value: "Working on Frontend"
          }
        }
      ]
    });
    setWorkIndex((prevState) => prevState + 1);
    setworkInputList((prevState) => !prevState);
  };

  const workInput = (index) => {
    return (
      <form Validate onSubmit={handleShift}>
        <h1 className="form-heading">Recent Professional Experience</h1>
        <p className="form-subheading">
          Add your most recent job and continue in descending order.
        </p>
        <TextField
          placeholder="Enter your Position"
          label="Position"
          name="Position"
          variant="standard"
          fullWidth
          required
          className="field2-left"
          value={formValues.workExp[index].Position.value}
          onChange={(e) => handleChange(e, index)}
        />
        <TextField
          placeholder="Enter your Company Name"
          label="Company Name"
          name="CompanyName"
          variant="standard"
          fullWidth
          required
          className="field2-right"
          value={formValues.workExp[index].CompanyName.value}
          onChange={(e) => handleChange(e, index)}
        />
        <TextField
          id="standard-select-currency"
          className="Selectbox"
          select
          name="monthStart"
          onChange={(e) => handleChange(e, index)}
          helperText="Please select Start Month"
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          className="Selectbox"
          name="yearStart"
          onChange={(e) => handleChange(e, index)}
          helperText="Please select Start Year"
        >
          {years.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          name="monthEnd"
          className="Selectbox"
          onChange={(e) => handleChange(e, index)}
          helperText="Please select end Month"
        >
          {options.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          id="standard-select-currency"
          select
          className="Selectbox"
          name="yearEnd"
          onChange={(e) => handleChange(e, index)}
          helperText="Please select end Year"
        >
          {years.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          placeholder="Enter About your Job"
          label="Description"
          name="Description"
          fullWidth
          multiline
          rows={8}
          className="field"
          value={formValues.workExp[index].Description.value}
          onChange={(e) => handleChange(e, index)}
        />
        <div className="stepButton">
          <Button onClick={handleBack}>Back</Button>
          <Button variant="contained" color="primary" type="submit">
            Continue
          </Button>
        </div>
      </form>
    );
  };
  const handleShift = () => {
    setworkInputList((prevState) => !prevState);
  };
  return <div>{workInputList === true ? workInput(workIndex) : workList()}</div>;
};
export default WorkInfo;
