import React from "react";
import { Button, TextField } from "@material-ui/core";
import "../styles.css";
const Profile = ({ handleChange, formValues, handleBack }) => {
  const handleFinish = () => {
    alert("you have filled all the details");
  };
  return (
    <form Validate onSubmit={handleFinish}>
      <h1 className="form-heading">Profile</h1>
      <p className="form-subheading">
        Featuring a professional summary introduces you to hiring managers.{" "}
      </p>
      <TextField
        placeholder="Enter About Yourself"
        label="Profile"
        name="profile"
        // variant="standard"
        fullWidth
        multiline
        rows={15}
        required
        className="field"
        value={formValues.profile.value}
        onChange={handleChange}
      />

      <div className="stepButton">
        <Button onClick={handleBack}>Back</Button>
        <Button variant="contained" color="primary" type="submit">
          Finish
        </Button>
      </div>
    </form>
  );
};
export default Profile;
