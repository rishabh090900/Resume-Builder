import React from "react";
import "./component.css";
import Avatar from "@material-ui/core/Avatar";

function Display({ formData }) {
  console.log(formData.image);
  return (
    <div className="template">
      <div className="headerTemp">
        <div className="headerright">
          <div className="name">
            {formData.firstName.value} {formData.lastName.value}
          </div>
          <span className="jobTitle"> {formData.jobTitle.value}</span>
        </div>
        <div className="headerleft">
          <Avatar className="profileImage" src={formData.image}>
            {formData.firstName.value.charAt(0).toUpperCase()}
            {formData.lastName.value.charAt(0).toUpperCase()}
          </Avatar>
          <span className="address">
            {formData.address.value}
            <br></br>
            {formData.city.value},{formData.state.value},{formData.pincode.value}
            <br></br>
            {formData.phone.value}
            <br></br>
            {formData.email.value}
          </span>
        </div>
      </div>
      <div className="profile"> {formData.profile.value} </div>
      <h2 className="titles">Education</h2>
      {formData.Education.map((index) => (
        <div className="education">
          <div className="educationLeft">
            <span className="education-degree">
              {index.degree.value} in {index.fieldStudy.value}
            </span>
            <br></br>
            <span> {index.Schoolname.value}</span>
            <br></br>
            <span> {index.SchoolLocation.value}</span>
            <br></br>
            <span>
              {index.monthStart.value}, {index.yearStart.value}-{index.monthEnd.value},{" "}
              {index.yearEnd.value}
            </span>
          </div>
          <div className="educationRight">{index.Description.value}</div>
        </div>
      ))}
      <h2 className="titles">Professional Experience</h2>
      {formData.workExp.map((index) => (
        <div className="experience">
          <div className="experienceLeft">
            <span className="experience-degree">
              {index.Position.value}
              <br></br>
              {index.CompanyName.value}
            </span>

            <br></br>
            <span>
              {index.monthStart.value}, {index.yearStart.value}-{index.monthEnd.value},{" "}
              {index.yearEnd.value}
            </span>
          </div>
          <div className="experienceRight">{index.Description.value}</div>
        </div>
      ))}
      <h2 className="titles">Projects</h2>
      {formData.project.map((index) => (
        <div className="experience">
          <div className="experienceLeft">
            <span className="experience-degree">
              {index.Name.value}
              <br></br>
              {index.TechUsed.value}
            </span>

            <br></br>
            <span>
              {index.monthStart.value}, {index.yearStart.value}-{index.monthEnd.value},{" "}
              {index.yearEnd.value}
            </span>
          </div>
          <div className="experienceRight">{index.Description.value}</div>
        </div>
      ))}
      <h2 className="titles">Key Skills</h2>
      <div className="keyskills">
        <ul>
          {formData.keySkills.map((i) => (
            <li className="keyskills-li">{i.value}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
export default React.memo(Display);
