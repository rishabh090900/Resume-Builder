import React, { useState, useEffect } from "react";
import { Button, TextField } from "@material-ui/core";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";

import "../styles.css";
const ContactInfo = ({ handleSubmit, handleChange, formValues, setFormValues }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  useEffect(() => {
    if (selectedImage) {
      console.log(selectedImage.size);
      if (!selectedImage.name.match(/\.(jpg|jpeg|png|gif)$/)) {
        alert("select valid image.");
      } else {
        if (selectedImage.size > 300000) alert("select image less than 300 kb");
        else setFormValues({ ...formValues, image: URL.createObjectURL(selectedImage) });
      }
    }
  }, [selectedImage]);
  return (
    <form noValidate onSubmit={handleSubmit}>
      <h1 className="form-heading">Contact Information</h1>
      <p className="form-subheading">Include at minimum your email and phone number</p>
      <TextField
        placeholder="Enter your Firstname"
        label="Firstname"
        name="firstName"
        variant="standard"
        fullWidth
        required
        className="field2-left"
        value={formValues.firstName.value}
        onChange={handleChange}
        error={formValues.firstName.error}
        helperText={formValues.firstName.error && formValues.firstName.errorMessage}
      />
      <TextField
        placeholder="Enter your Lastname"
        label="Lastname"
        name="lastName"
        variant="standard"
        fullWidth
        required
        className="field2-right"
        value={formValues.lastName.value}
        onChange={handleChange}
        error={formValues.lastName.error}
        helperText={formValues.lastName.error && formValues.lastName.errorMessage}
      />
      <TextField
        placeholder="Enter your Job Title"
        label="Job Title"
        name="jobTitle"
        variant="standard"
        fullWidth
        required
        className="field2-left"
        value={formValues.jobTitle.value}
        onChange={handleChange}
        error={formValues.jobTitle.error}
        helperText={formValues.jobTitle.error && formValues.jobTitle.errorMessage}
      />
      <>
        <input
          accept="image/*"
          type="file"
          id="select-image"
          style={{ display: "none" }}
          onChange={(e) => setSelectedImage(e.target.files[0])}
        />
        <label htmlFor="select-image">
          <Button
            className="inputButton"
            variant="contained"
            color="primary"
            component="span"
            onChange={(e) => setSelectedImage(e.target.files[0])}
          >
            Upload Image
          </Button>
        </label>
      </>
      <DeleteOutlineIcon onClick={() => setFormValues({ ...formValues, image: " " })} />
      <TextField
        placeholder="Enter your Address"
        label="Address"
        name="address"
        variant="standard"
        fullWidth
        required
        className="field1"
        value={formValues.address.value}
        onChange={handleChange}
        error={formValues.address.error}
        helperText={formValues.address.error && formValues.address.errorMessage}
      />
      <TextField
        placeholder="Enter your city"
        label="City"
        name="city"
        variant="standard"
        fullWidth
        required
        className="field31"
        value={formValues.city.value}
        onChange={handleChange}
        error={formValues.city.error}
        helperText={formValues.city.error && formValues.city.errorMessage}
      />
      <TextField
        placeholder="Enter your state"
        label="State"
        name="state"
        variant="standard"
        fullWidth
        required
        className="field32"
        value={formValues.state.value}
        onChange={handleChange}
        error={formValues.state.error}
        helperText={formValues.state.error && formValues.state.errorMessage}
      />
      <TextField
        placeholder="Enter your pincode"
        label="Pincode"
        name="pincode"
        variant="standard"
        type="number"
        fullWidth
        required
        className="field33"
        value={formValues.pincode.value}
        onChange={handleChange}
        error={formValues.pincode.error}
        helperText={formValues.pincode.error && formValues.pincode.errorMessage}
      />
      <TextField
        placeholder="Enter your phone"
        label="Phone"
        name="phone"
        variant="standard"
        type="number"
        fullWidth
        required
        className="field2-left"
        value={formValues.phone.value}
        onChange={handleChange}
        error={formValues.phone.error}
        helperText={formValues.phone.error && formValues.phone.errorMessage}
      />
      <TextField
        placeholder="Enter your email"
        label="Email"
        name="email"
        variant="standard"
        type="email"
        fullWidth
        required
        className="field2-right"
        value={formValues.email.value}
        onChange={handleChange}
        error={formValues.email.error}
        helperText={formValues.email.error && formValues.email.errorMessage}
      />
      <br></br>
      <div className="stepButton">
        <Button variant="contained" color="primary" type="submit">
          Continue
        </Button>
      </div>
    </form>
  );
};
export default ContactInfo;
