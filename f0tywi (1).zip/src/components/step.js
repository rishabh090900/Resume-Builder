import React, { useState } from "react";
import { Button, TextField, Typography } from "@material-ui/core";
import { KeyboardArrowRight } from "@material-ui/icons";
import "../styles.css";
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";

function getSteps() {
  return [
    "Contact Information",
    "Education",
    "Work Experience",
    "Projects Information",
    "Key Skills",
    "Profile"
  ];
}
function Stepline({ StepIndex }) {
  const steps = getSteps();

  return (
    <div>
      <Stepper activeStep={StepIndex} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </div>
  );
}

export default Stepline;
