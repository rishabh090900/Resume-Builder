import React, { useState, useEffect, useRef } from "react";
import "./styles.css";

import Form from "./components/form";
import Display from "./components/display";
import Step from "./components/step";
import Header from "./components/header";
export default function App() {
  const [formData, setFormData] = useState(null);
  const [stepIndex, setSteIndex] = useState(0);
  const [Index, setIndex] = useState(null);
  const getContent = (index) => {
    switch (index) {
      case 0:
        return <>{formData ? <Display formData={formData} /> : null}</>;
      default:
        return <div>{formData ? <Display formData={formData} /> : null}</div>;
    }
  };
  const displayContent = (index) => {
    return (
      <div className="App">
        <Header />
        <div className="content">
          <>{getContent(index)}</>
          <Form setFormData={setFormData} setStepIndex={setSteIndex} stepIndex={stepIndex} />
        </div>
        <div className="Step">
          <Step StepIndex={stepIndex} />
        </div>
      </div>
    );
  };

  const handleIndex = () => {
    setIndex(0);
  };
  return (
    <div className="App">
      {Index === null ? (
        <>
          <Header />
          <div className="frontPage-box">
            {" "}
            {formData ? (
              <button className="frontPage" onClick={handleIndex}>
                <Display formData={formData} />
              </button>
            ) : null}
          </div>
          <div className="notshow">
            <Form setFormData={setFormData} setStepIndex={setSteIndex} stepIndex={stepIndex} />
          </div>
        </>
      ) : (
        <>{displayContent(Index.current)}</>
      )}
    </div>
  );
  // return (
  //   <div className="App">
  //     <Header />
  //     <div className="content">
  //       {formData ? <Display formData={formData} /> : null}
  //       <Form
  //         setFormData={setFormData}
  //         setStepIndex={setSteIndex}
  //         stepIndex={stepIndex}
  //       />
  //     </div>
  //     <div className="Step">
  //       <Step StepIndex={stepIndex} />
  //     </div>
  //   </div>
  // );
}
