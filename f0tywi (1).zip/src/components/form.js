import React, { useState, useRef, useEffect } from "react";
import "./component.css";
import ContactInfo from "./contactInfo";
import EduInfo from "./eduInfo.js";
import WorkInfo from "./workInfo.js";
import KeySkills from "./keySkill.js";
import Profile from "./profile.js";
import Project from "./projects.js";
function Form({ setFormData, setStepIndex, stepIndex }) {
  const move = useRef(null);
  const [formValues, setFormValues] = useState({
    firstName: {
      value: "John",
      error: false,
      errorMessage: "You must enter a first name"
    },
    lastName: {
      value: "Mathews",
      error: false,
      errorMessage: "You must enter a last name"
    },
    jobTitle: {
      value: "Software Developer",
      error: false,
      errorMessage: "You must enter a job Title"
    },
    image: " ",

    address: {
      value: "53 street",
      error: false,
      errorMessage: "You must enter your address"
    },
    city: {
      value: "Newyork",
      error: false,
      errorMessage: "You must enter your city"
    },
    state: {
      value: "Atlanta",
      error: false,
      errorMessage: "You must enter state"
    },
    pincode: {
      value: "50301",
      error: false,
      errorMessage: "You must enter pincode"
    },
    phone: {
      value: "2314567890",
      error: false,
      errorMessage: "You must enter mobile no."
    },
    email: {
      value: "xyz@gmail.com",
      error: false,
      errorMessage: "You must enter email"
    },
    profile: {
      value:
        "Human resources generalist with 8 years of experience in HR, including hiring and terminating, disciplining employees and helping department managers improve employee performance. Worked with labor unions to negotiate compensation packages for workers. Organized new hire training initiatives as well as ongoing training to adhere to workplace safety standards. Worked with OSHA to ensure that all safety regulations are followed.",
      error: false,
      errorMessage: "You must enter atleast 50 words"
    },
    Education: [
      {
        Schoolname: {
          value: "Cambridge University",
          error: false,
          errorMessage: "You must enter school name"
        },
        SchoolLocation: {
          value: "Jaipur"
        },
        degree: {
          value: "B.tech",
          error: false,
          errorMessage: "You must enter degree"
        },
        monthStart: {
          value: "july"
        },
        yearStart: {
          value: "2019"
        },

        monthEnd: {
          value: "july"
        },
        yearEnd: {
          value: "2023"
        },
        fieldStudy: {
          value: "Computer Science",
          error: false,
          errorMessage: "You must enter school name"
        },
        Description: {
          value: "Learned a lot in my betch , proficienct in Frontend and backend"
        }
      }
    ],
    workExp: [
      {
        id: 1,
        Position: {
          value: "UI/Ux Intern"
        },
        CompanyName: {
          value: "Google"
        },

        monthStart: {
          value: "July"
        },

        yearStart: {
          value: "2021"
        },

        monthEnd: {
          value: "August"
        },
        yearEnd: {
          value: "2021"
        },
        Description: {
          value: "Working on Frontend"
        }
      }
    ],
    project: [
      {
        id: 1,
        Name: {
          value: "Resume Builder"
        },
        TechUsed: {
          value: "React"
        },

        monthStart: {
          value: "July"
        },

        yearStart: {
          value: "2022"
        },

        monthEnd: {
          value: "December"
        },
        yearEnd: {
          value: "2022"
        },
        Description: {
          value: "Building Resume using software"
        }
      }
    ],
    keySkills: [
      { id: 1, value: "java" },
      { id: 2, value: "HTML" },
      {
        id: 3,
        value: "React"
      },
      {
        id: 4,
        value: "JavaScript"
      }
    ]
  });
  setFormData(formValues);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: {
        ...formValues[name],
        value
      }
    });
    setFormData({
      ...formValues,
      [name]: {
        ...formValues[name],
        value
      }
    });
  };
  const handleSubmit = (e) => {
    move.current = true;
    e.preventDefault();
    const formFields = Object.keys(formValues);
    let newFormValues = { ...formValues };
    for (let index = 0; index < formFields.length; index++) {
      const currentField = formFields[index];
      const currentValue = formValues[currentField].value;
      if (currentValue === "") {
        newFormValues = {
          ...newFormValues,
          [currentField]: {
            ...newFormValues[currentField],
            error: true
          }
        };
        move.current = false;
      }
    }
    setFormData(newFormValues);
    handleNext(move);
    setFormValues(newFormValues);
  };
  const handleChange1 = (e, index) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: {
        ...formValues[name],
        value
      }
    });
    setFormData({
      ...formValues,
      [name]: {
        ...formValues[name],
        value
      }
    });
  };

  const handleNext = (Move) => {
    if (Move.current) setStepIndex((prevActiveStep) => prevActiveStep + 1);
  };
  const handleNext1 = () => {
    setStepIndex((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setStepIndex((prevActiveStep) => prevActiveStep - 1);
  };

  function getStepContent(Index) {
    switch (Index) {
      case 0:
        return (
          <ContactInfo
            handleChange={handleChange}
            handleSubmit={handleSubmit}
            formValues={formValues}
            setFormValues={setFormValues}
          />
        );
      case 1:
        return (
          <EduInfo
            handleChange={handleChange1}
            handleNext={handleNext1}
            formValues={formValues}
            handleBack={handleBack}
            setFormValues={setFormValues}
          />
        );
      case 2:
        return (
          <WorkInfo
            handleChange={handleChange1}
            handleSubmit={handleNext1}
            formValues={formValues}
            handleBack={handleBack}
            setFormValues={setFormValues}
          />
        );
      case 3:
        return (
          <Project
            handleChange={handleChange1}
            handleSubmit={handleNext1}
            formValues={formValues}
            handleBack={handleBack}
            setFormValues={setFormValues}
          />
        );
      case 4:
        return (
          <KeySkills
            handleChange={handleChange1}
            handleSubmit={handleNext1}
            formValues={formValues}
            handleBack={handleBack}
            setFormValues={setFormValues}
          />
        );
      case 5:
        return (
          <Profile handleChange={handleChange} formValues={formValues} handleBack={handleBack} />
        );
      default:
        return "Unknown stepIndex";
    }
  }

  return <div className="Form">{getStepContent(stepIndex)}</div>;
}
export default React.memo(Form);
