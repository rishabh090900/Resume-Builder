import React, { useState } from "react";
import { Button, TextField } from "@material-ui/core";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import AddSharpIcon from "@material-ui/icons/AddSharp";
import "../styles.css";
const KeySkills = ({ handleSubmit, formValues, handleBack, setFormValues }) => {
  const handleChange = (e, index) => {
    const { name, value } = e.target;
    const newSkills = formValues.keySkills.map((i, ind) => {
      if (index === ind) {
        i.id = ind + 1;
        i[name] = value;
        // i[name] = value;
        console.log(i);
      }
      return i;
    });
    setFormValues({ ...formValues, keySkiils: newSkills });
  };

  const handleaddclick = (index) => {
    const newList = formValues.keySkills;

    setFormValues({
      ...formValues,
      keySkills: [
        ...newList,
        {
          id: "",
          value: ""
        }
      ]
    });
  };
  const handleRemove = (e) => {
    if (e >= 0) {
      const elementRemove = formValues.keySkills[e];
      let removeSkills = formValues.keySkills.filter((keySkills) => keySkills !== elementRemove);
      setFormValues({ ...formValues, keySkills: removeSkills });
    }
  };

  return (
    <form noValidate onSubmit={handleSubmit}>
      <h1 className="form-heading">Key Skills</h1>
      <p className="form-subheading">Add relevant professional key skills and proficiencies.</p>
      <div className="keySkills-list">
        {formValues.keySkills.map((i, index) => {
          return (
            <div>
              <TextField
                name="value"
                variant="standard"
                fullWidth
                required
                className="field-skills"
                value={i.value}
                onChange={(e) => handleChange(e, index)}
              />
              <DeleteOutlineIcon classname="btn-skills1" onClick={() => handleRemove(index)}>
                Remove
              </DeleteOutlineIcon>
            </div>
          );
        })}
      </div>
      <Button className="btn-skills2" onClick={handleaddclick}>
        <AddSharpIcon /> Add More
      </Button>
      <div className="stepButton">
        <Button onClick={handleBack}>Back</Button>
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Continue
        </Button>
      </div>
    </form>
  );
};
export default KeySkills;
